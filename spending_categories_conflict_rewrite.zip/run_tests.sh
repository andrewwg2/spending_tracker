#!/bin/sh

export CI=true
npm test ${@}